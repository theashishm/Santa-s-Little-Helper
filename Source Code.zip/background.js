// Initialize shortcuts when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    shortcuts: {
      "ye": "https://www.youtube.com",
      "gb": "https://github.com",
      "news": "https://news.google.com",
      "rt": "https://www.reddit.com",
      "mm": "https://medium.com",
      "nx": "https://www.netflix.com"
    }
  });
  console.log("Santa's Little Helper: Shortcuts initialized!");
});

// Handle omnibox input
chrome.omnibox.onInputEntered.addListener((text, disposition) => {
  console.log(`Omnibox input entered: ${text}`);
  chrome.storage.sync.get("shortcuts", (data) => {
    const shortcuts = data.shortcuts || {};
    const url = shortcuts[text];
    if (url) {
      console.log(`Redirecting to: ${url}`);
      chrome.tabs.create({ url });
    } else {
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(text)}`;
      console.log(`Performing Google search: ${searchUrl}`);
      chrome.tabs.create({ url: searchUrl });
    }
  });
});

// Listen for messages from other parts of the extension (if needed)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message received in background script:", message);
});
