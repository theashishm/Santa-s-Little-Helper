document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("shortcutForm");
  const list = document.getElementById("shortcutsList");

  const loadShortcuts = () => {
    chrome.storage.sync.get("shortcuts", (data) => {
      list.innerHTML = "";
      const shortcuts = data.shortcuts || {};
      for (const [key, url] of Object.entries(shortcuts)) {
        const li = document.createElement("li");
        li.textContent = `${key} → ${url}`;
        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.onclick = () => {
          delete shortcuts[key];
          chrome.storage.sync.set({ shortcuts }, loadShortcuts);
        };
        li.appendChild(deleteButton);
        list.appendChild(li);
      }
    });
  };

  form.onsubmit = (e) => {
    e.preventDefault();
    const shortcut = document.getElementById("shortcut").value.trim();
    const url = document.getElementById("url").value.trim();
    chrome.storage.sync.get("shortcuts", (data) => {
      const shortcuts = data.shortcuts || {};
      shortcuts[shortcut] = url;
      chrome.storage.sync.set({ shortcuts }, loadShortcuts);
    });
    form.reset();
  };

  loadShortcuts();
});
